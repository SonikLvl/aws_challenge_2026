import boto3
import os

def lambda_handler(event, context):
    client = boto3.client('codebuild')
    response = client.start_build(projectName=os.environ['CODEBUILD_PROJECT_NAME'])
    return {'message': 'Build started'}
